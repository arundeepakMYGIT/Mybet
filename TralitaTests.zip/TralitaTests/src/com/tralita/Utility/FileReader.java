package com.tralita.Utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class FileReader {
	
	public Properties getProperty() throws IOException
	{
		FileInputStream inputStream = null;
		Properties properties = new Properties();
		try
		{
			properties.load(new FileInputStream("Resources/Testdata.properties"));
		}
		catch (Exception e)
		{
			System.out.println("Exception: " +e);
		}
		return properties;
	}

}
