package com.tralita.PageObjects;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.genericClass.BrowserFactory;
import com.genericClass.GenericClass;
import com.tralita.Utility.FileReader;

public class PageObjects_TralitaLogin {
	
	WebDriver driver;
	FileReader FR = new FileReader();
	GenericClass GC = new GenericClass();
	BrowserFactory BF = new BrowserFactory();
	
	public PageObjects_TralitaLogin (WebDriver iDriver)
	{
		this.driver = iDriver;
		
	}
	
	// Tralita Web Elemente
	@FindBy(xpath = "//*[@class=\"headline\"]")
	public
	WebElement anmeldungTextaufLoginSeite;
	
	@FindBy(xpath = "//*[@id=\"userid\"]")
	public
	WebElement tralitaBenutzerTextfeld;
	
	@FindBy(xpath = "//*[@name=\"password\"]")
	public
	WebElement tralitaPasswordTextfeld;
	
	@FindBy(xpath = "//*[@name=\"submit\"]")
	public
	WebElement tralitaAnmeldenButton;
	
	
	public void tralitaWebAnmelden(String benutzerName, String passwort) throws InterruptedException, IOException
	{
		BF.ExecuteActionOnPage(tralitaBenutzerTextfeld, "sendKeys", benutzerName);
		BF.ExecuteActionOnPage(tralitaPasswordTextfeld, "sendKeys", passwort);
		BF.ExecuteActionOnPage(tralitaAnmeldenButton, "click", "");
		
	}
	
	public boolean loginSeiteTralita()
	{
		return anmeldungTextaufLoginSeite.isDisplayed();
	}

}
