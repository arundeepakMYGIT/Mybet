package com.tralita.PageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PageObjects_MarisLogin {
	
	// MARIS Windows Elemente
		@FindBy(xpath = "//*[@AutomationId='_txtUsername']")
		public
		WebElement marisBenutzerNameTextfeld;
		
		@FindBy(xpath = "//*[@AutomationId='_txtPasswort']")
		public
		WebElement marisPasswortTextfeld;
		
		@FindBy(xpath = "//*[@AutomationId='_btnOK']")
		public
		WebElement marisAnmeldenButton;

		@FindBy(xpath = "//*[@ClassName='WindowsForms10.Window.8.app.0.1fed012_r3_ad1']")
		public
		WebElement marisFehlerbeiAnmeldung;

}
