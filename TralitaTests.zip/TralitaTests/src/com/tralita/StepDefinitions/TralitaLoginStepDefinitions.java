package com.tralita.StepDefinitions;

import java.io.IOException;
import java.net.URL;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.winium.DesktopOptions;
import org.openqa.selenium.winium.WiniumDriver;
import org.testng.Assert;

import com.genericClass.BrowserFactory;
import com.genericClass.GenericClass;
import com.tralita.PageObjects.PageObjects_TralitaLogin;
import com.tralita.Utility.FileReader;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TralitaLoginStepDefinitions {
	WebDriver driver;
	PageObjects_TralitaLogin TLP;
	
	//GenericClass GC = new GenericClass();
	//PageObjects_TralitaLogin TL = new PageObjects_TralitaLogin(); 
	
//	driver = BrowserFactory.browser(driver, "chrome", "https://tralita.test.intern/tralitav2/");
//	PageObjects_TralitaLogin TLP = PageFactory.initElements(driver, PageObjects_TralitaLogin.class);
	FileReader FR = new FileReader();
	
//	public TralitaLoginStepDefinitions() throws IOException
//	{
//		GC = new GenericClass();
//	}
	
	
//	public GenericClass GC = null;
//	public PageObjects_Tralita_Maris PO = null;
//	//public WebDriver driver;
//	FileReader TD = new FileReader();
//	
//	// Classname
//	private String className = this.getClass().getName();
//	
//	// Reihenwert in Excel
//	public final int column = 8;
//	
//	public String methodName;
//	public String projektName = "Tralita";
//	public String TC = "Login";
	//FileReader obj = new FileReader();
//	
//	public TralitaLoginStepDefinitions() throws Exception
//	{
//		GC = new GenericClass();
//		PO = new PageObjects_Tralita_Maris();
//		TD = new FileReader();
//	}
	
//	@Given("^Launch Google Home Page$")
//	public void launchGoogle() throws IOException
//	{
//		Properties properties = FR.getProperty();
//		System.setProperty("webdriver.chrome.driver", "Resources/chromedriver.exe");
//		WebDriver driver = new ChromeDriver();
//		driver.get(properties.getProperty("Googletestdata"));
//		driver.manage().window().maximize();
//		Assert.assertTrue(driver.getTitle().equals(properties.getProperty("Goo")));
//	}
	
	@Given("^Tralita Webanwendung aufrufen$")
	public void tralitaWebAufrufen() throws IOException
	{
		driver = BrowserFactory.browser(driver, "chrome", "https://tralita.test.intern/tralitav2/");
		TLP = PageFactory.initElements(driver, PageObjects_TralitaLogin.class);
		
		Properties properties = FR.getProperty();
		//driver = BrowserFactory.browser(driver, "chrome", "https://tralita.test.intern/tralitav2/");
		System.out.println(driver.getTitle());
		//GC.ChromeSetup(properties.getProperty("TralitaLink")); ----
		//PageObjects_TralitaLogin TLP = PageFactory.initElements(driver, PageObjects_TralitaLogin.class);
		//GC.ChromeSetup(FR.getProperty("Googletestdata"));
		
//		System.setProperty("webdriver.chrome.driver", "Resources/chromedriver.exe");
//		WebDriver driver = new ChromeDriver();
//		GC.driver.get(properties.getProperty("Googletestdata"));
//		GC.driver.manage().window().maximize();
	}
	
//	@Then("^Tralita Login Fenster ist angezeigt$")
//	public void anzeigeTralitaLoginSeitePruefen() throws IOException
//	{
//		//Assert.assertTrue(TL.loginSeiteTralita());
//		
//		if(TL.anmeldungTextaufLoginSeite.isDisplayed())
//		{
//			System.out.println("is displayed");
//		}
//		else
//		{
//			System.out.println("is not displayed");
//		}
		
//		try{
//		if(WE.marisFehlerbeiAnmeldung.isDisplayed())
//		{
//			GC.TestCasePassDisplay(1, projektName, TC, "Maris Einloggen mit ungueltigen Zugangsdaten pr�fen", 3, column);
//		}
//		else
//		{
//			GC.TestCaseFailDisplay(1, projektName, TC, "Maris Einloggen mit ungueltigen Zugangsdaten pr�fen", 3, column);
//		}
//		
//	}
//	
//	catch (Exception e)
//	{
//		GC.TestCaseFailDisplay(1, projektName, TC, "Maris Einloggen mit ungueltigen Zugangsdaten pr�fen", 3, column);
//	}
//	}
	
	@When("^ungueltige Benutzername, Passwort eingeben und auf Anmelden Button klicken$")
	public void tralitaEinloggenMitUngueltigenZugangsdaten() throws IOException, InterruptedException
	{
		Properties properties = FR.getProperty();
		
		//driver.findElement(By.xpath("//*[@id=\"userid\]"))
		TLP.tralitaWebAnmelden(properties.getProperty("TralitaBenutzername"), properties.getProperty("TralitaPasswort"));
		//TLP.tralitaWebAnmelden(properties.getProperty("TralitaBenutzername"), properties.getProperty("TralitaPasswort"));
		//TL.tralitaWebAnmelden(properties.getProperty("TralitaBenutzername"), properties.getProperty("TralitaPasswort"));
	}
	
	
	

}

//	Given Maris Windows Anwendung aufrufen
//Then Maris Login Fenster ist angezeigt
//When ungueltige Benutzername, Passwort eingeben und auf Anmelden Button klicken
//Then Fehlermeldung ist angezeigt
//when gueltige Benutzername, Passwort und auf Anmelden Button klicken
//Then Maris Homeseite ist angezeigt
