package com.tralita.TestRunner;

import java.net.URL;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.winium.DesktopOptions;
import org.openqa.selenium.winium.WiniumDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;

//@CucumberOptions(
//		features = "./Features",
//		glue = {"com.tralita.StepDefinitions"},
//		tags = {"@MarisLogin"},
//		plugin= {"pretty",
//				"html:target/cucumber-reports/cucumber.html",
//				"json:target/cucumber-reports/cucumber.json" 
//				},
//		monochrome = true)
//		
//public class TestRunner {
//	private TestNGCucumberRunner testNGCucumberRunner;
//	
//	@BeforeClass(alwaysRun = true)
//	public void setupClass() throws Exception
//	{
//		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
//	}
//	
//	@Test(groups="cucumber", description="Runs cucumber Features", dataProvider = "features")
//	public void feature(CucumberFeatureWrapper cucumberFeature)
//	{
//		testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
//	}
//	
//	@DataProvider
//	public Object[][] features()
//	{
//		return testNGCucumberRunner.provideFeatures();
//	}
//	
//	@AfterClass(alwaysRun = true)
//	public void tearDownClass() throws Exception
//	{
//		testNGCucumberRunner.finish();
//	}
//}

@CucumberOptions(
		plugin= {"pretty",
				"html:target/cucumber-reports/cucumber.html",
				"json:target/cucumber-reports/cucumber.json" 
				},
		features = {"feature/Features"},
		glue = {"com.tralita.StepDefinitions"}
)

public class TestRunner extends AbstractTestNGCucumberTests {
	
}