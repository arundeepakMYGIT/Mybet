package com.genericClass;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;

import org.apache.log4j.Appender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class BrowserFactory {
	
	public static Logger Log;
	
	public BrowserFactory() {
		try {
			Loginit(this.getClass().getName());

		} catch (Exception e) {
			throw new IllegalStateException("Exception: Can't start the browser", e);
		}
	}
	
	// #######################################################################################################
			// Description: Log4j initialization function, with its classname
			// testclass as the parameter
			// #######################################################################################################
			@SuppressWarnings("rawtypes")
			public void Loginit(String classname) {

				Log = Logger.getLogger(BrowserFactory.class);

				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
				// get current date time with Date()
				Date date = new Date();
				String d = dateFormat.format(date);

				String logs = "LOGS/";

				Logger rootLogger = Logger.getRootLogger();
				Enumeration appenders = rootLogger.getAllAppenders();
				FileAppender fa = null;
				while (appenders.hasMoreElements()) {
					Appender currAppender = (Appender) appenders.nextElement();
					if (currAppender instanceof FileAppender) {
						fa = (FileAppender) currAppender;
					}
				}
				if (fa != null) {
					fa.setFile(logs + classname + "/" + d + ".log");
					fa.activateOptions();
				} else {
					Log.info("--- No File Appender found");
				}
			}
	
	public static WebDriver browser(WebDriver driver, String browserName, String URL)
	{
		if(browserName.equals("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "Resources/chromedriver.exe");
			driver = new ChromeDriver();
			driver.get(URL);
			driver.manage().window().maximize();
			//Log.info("--- Chrome Driver ist aufgerufen");
		}
		else if(browserName.equals("Firefox"))
		{
			Log.info("--- Firefox Driver ist aufgerufen");
		}
		else if(browserName.equals("IE"))
		{
			Log.info("--- IE Driver ist aufgerufen");
		}
		else
		{
			System.out.println("Bitte Browser Name �berpr�fen");
		}
		driver.manage().window().maximize();
		driver.get(URL);
		return driver;
	}
	
	public void ExecuteActionOnPage(WebElement xpath, String strAction, String strValue) throws InterruptedException {

		// @ Perform Action.
//		Actions action = new Actions(driver);
//		String parentHandle = driver.getWindowHandle(); // get the current window handle
//		WebDriverWait wait = new WebDriverWait(driver, 5);
//		xpath = wait.until(ExpectedConditions.elementToBeClickable(xpath));

//		try {
			switch (strAction) {
			case "click":
				Log.info("--- " + xpath.getText() + " element is clicked");
				xpath.click();
				// driver.findElement(By.id(username)).click();
				Thread.sleep(1500);
				break;

//			case "rightclick":
//				Log.info("--- " + xpath.getText() + " element is right clicked");
//				action.contextClick(xpath).perform();
//				Thread.sleep(1500);
//				break;

			case "sendKeys":
				//xpath.clear();
				Log.info("--- " + strValue + " is entered in the element" + xpath.getText());
				xpath.sendKeys(strValue);
				Thread.sleep(1500);
				break;

				//Actions need to be performed in between these two cases
//			case "closeWH":
//				driver.close(); // close newly opened window when done with it
//				driver.switchTo().window(parentHandle); // switch back to the original window
//				Log.info("--- Child window is closed");
//				break;

			case "uncheck":
				if ((xpath).isSelected()) {
					Log.info("--- " + xpath.getText() + " element is unchecked");
					xpath.click();
					Thread.sleep(1500);
					break;
				}

			case "selectbytext":
				Select sel = new Select(xpath);
				Log.info("--- " + xpath.getText() + " element is selected by visible text" + strValue);
				sel.selectByVisibleText(strValue);
				break;

			case "selectbyvalue":
				Select sel1 = new Select(xpath);
				Log.info("--- " + xpath.getText() + " element is selected by value" + strValue);
				sel1.selectByValue(strValue);
				break;

			case "selectbyindex":
				Select sel2 = new Select(xpath);
				Log.info("--- " + xpath.getText() + "element is selected by index" + strValue);
				sel2.selectByIndex(Integer.parseInt(strValue));
				break;

			case "deselectAll":
				Select sel3 = new Select(xpath);
				Log.info("--- " + xpath.getText() + " element is deselected");
				sel3.deselectAll();
				break;
			}
//		}
//		catch (Exception e)
//		{
//			
//		}
		
	}

}
