package com.genericClass;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
//import org.apache.poi.util.Removal;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;

import org.apache.log4j.Appender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;

import org.apache.commons.io.FileUtils;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.HasInputDevices;
import org.openqa.selenium.interactions.Locatable;
import org.openqa.selenium.interactions.Mouse;

public class GenericClass {
	
	// ########################################################################################################
		// ### Static and Dictionary key that are used in globally (Function level,

		public WebDriver driver = null;
		public Hashtable<String, String> dicConfig = new Hashtable<String, String>();
		public Hashtable<String, String> dicOutput = new Hashtable<String, String>();
		public String ErrDescription;
		// public static WebElement element = null;
		public List<WebElement> elements;
		public String StartDateExecution = "";
		public String EndDateExecution = "";
		public Logger Log;
		public String sReportFileName = "";

		private XSSFSheet ExcelWSheetTR;
		private XSSFWorkbook ExcelWBookTR;
		private XSSFCell CellTR;
		private XSSFRow RowTR;
		private String Path_TestDataTR;
		

		private static MissingCellPolicy xRow;
		private XSSFSheet ExcelWSheetTD;
		private XSSFWorkbook ExcelWBookTD;
		private XSSFCell CellTD;
		private XSSFRow RowTD;
		private String Path_TestDataTD;

		String result;

		// #######################################################################################################
		// Constructor: GenericClass
		// Description: Log4J declaration with this class name and call the browser
		// setup function
		// #######################################################################################################
		public GenericClass() {

			try {
				Loginit(this.getClass().getName());
				//IESetup();
				//ChromeSetup(URL);
				// FirefoxSetup();

			} catch (Exception e) {
				throw new IllegalStateException("Exception: Can't start the browser", e);
			}
		}


		// #######################################################################################################
		// Description: Log4j initialization function, with its classname
		// testclass as the parameter
		// #######################################################################################################
		@SuppressWarnings("rawtypes")
		public void Loginit(String classname) {

			Log = Logger.getLogger(GenericClass.class);

			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
			// get current date time with Date()
			Date date = new Date();
			String d = dateFormat.format(date);

			String logs = "LOGS/";

			Logger rootLogger = Logger.getRootLogger();
			Enumeration appenders = rootLogger.getAllAppenders();
			FileAppender fa = null;
			while (appenders.hasMoreElements()) {
				Appender currAppender = (Appender) appenders.nextElement();
				if (currAppender instanceof FileAppender) {
					fa = (FileAppender) currAppender;
				}
			}
			if (fa != null) {
				fa.setFile(logs + classname + "/" + d + ".log");
				fa.activateOptions();
			} else {
				Log.info("--- No File Appender found");
			}
		}


		// #######################################################################################################
		// Description: Navigate to the provided URL
		// #######################################################################################################
		public void getURL(String url) {
			driver.navigate().to(url);
		}

		// #######################################################################################################
		// Description: Titel von Login Page kreigen
		// #######################################################################################################
		public String GetPageTitel()
		{
			Log.info("- - - Page Titel ist: " +driver.getTitle());
			return driver.getTitle();
		}


		// #######################################################################################################
		// Description: IE browser Setup
		// #######################################################################################################
		public void IESetup() {
			System.setProperty("webdriver.ie.driver",
					"Resourcen/IEDriverServer.exe");
			// driver = new InternetExplorerDriver();
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			
			
			// capabilities.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
			// capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
			// capabilities.setCapability("ignoreProtectedModeSettings", true);
			// capabilities.setCapability("disable-popup-blocking", true);
			// capabilities.setCapability("enablePersistentHover", true);
			driver = new InternetExplorerDriver(capabilities);
			Log.info("--- IE Driver is invoked");
		}

		// #######################################################################################################
	        // Description: IE browser Setup
	        // #######################################################################################################
	        public void EdgeSetup() {
	                System.setProperty("webdriver.edge.driver", "Resources/msedgedriver.exe");
	                DesiredCapabilities capabilities = DesiredCapabilities.edge();
	                driver = new EdgeDriver(capabilities);
	                driver = new EdgeDriver();

	                driver.manage().window().maximize();
	                Log.info("--- Edge Driver is invoked");
	        }


		// #######################################################################################################
		// Description: Chrome browser Setup
		// #######################################################################################################
		public void ChromeSetup(String URL) {
//			System.setProperty("webdriver.chrome.driver", "Resources/chromedriver.exe");
//			ChromeOptions options = new ChromeOptions();
//			options.addArguments("--start-maximized");
//			//driver = new ChromeDriver(options);
//			Log.info("--- Chrome Driver is invoked");


			System.setProperty("webdriver.chrome.driver", "Resources/chromedriver.exe");
			driver = new ChromeDriver();
			driver.get(URL);
			driver.manage().window().maximize();
			Log.info("--- Chrome Driver ist aufgerufen");
		}


		// #######################################################################################################
		// Description: Navigate to the provided URL
		// #######################################################################################################
		public void FirefoxSetup() {
			System.setProperty("webdriver.gecko.driver", "Resources/geckodriver.exe");

			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability("firefox_binary","Resourcen/geckodriver.exe");

			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();







			//FirefoxProfile profile = new FirefoxProfile();

			//profile.setAcceptUntrustedCertificates(true);
			//profile.setAssumeUntrustedCertificateIssuer(false);
			//driver = new FirefoxDriver(profile);

			// ProfilesIni profile = new ProfilesIni();
			// FirefoxProfile myprofile = profile.getProfile("default");
			// myprofile.setAcceptUntrustedCertificates(true);
			// myprofile.setAssumeUntrustedCertificateIssuer(true);
			// driver = new FirefoxDriver(myprofile);

			// DesiredCapabilities dc = DesiredCapabilities.firefox();
			// dc.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			//
			// FirefoxProfile profile = new FirefoxProfile();
			// profile.setAcceptUntrustedCertificates(true);
			//
			// dc.setCapability(FirefoxDriver.PROFILE, profile);
			//
			// // this is the important line - i.e. don't use Marionette
			// dc.setCapability(FirefoxDriver.MARIONETTE, false);
			//
			// driver = new FirefoxDriver(dc);

			//DesiredCapabilities dc = DesiredCapabilities.firefox();
			//dc.setCapability(FirefoxDriver.MARIONETTE, false);

			// ffProfilePath =
			// "C:\Users\arundeepak\AppData\Roaming\Mozilla\Firefox\Profiles\sm7mmj99.Standard-Benutzer";
			// profile = webdriver.FirefoxProfile(profile_directory=ffProfilePath)
			// geckoPath = 'D:\Work\PyTestFramework\geckodriver.exe'
			// browser = webdriver.Firefox(firefox_profile=profile,
			// capabilities=firefox_capabilities, executable_path=geckoPath)
			// browser.get('http://stackoverflow.com')

			Log.info("--- Firefox Driver is invoked");
		}


		// #######################################################################################################
		// Description: Execute actions on the browser level
		// #######################################################################################################
		@SuppressWarnings("unused")
		public boolean ExecuteActionOnBrowser(String strBrowserAction, String strValue) {

			boolean Flag = false;

			try {
				switch (strBrowserAction.toLowerCase().trim().replace(" ", "")) {
				case "back":
					driver.navigate().back();
					return true;
				case "forward":
					driver.navigate().forward();
					return true;
				case "refresh":
					driver.navigate().refresh();
					return true;
				case "maximize":
					driver.manage().window().maximize();
					return true;
				case "navigate":
					driver.navigate().to(strValue);
					driver.manage().window().maximize();
					return true;
				case "focus":
					switch (strValue.toLowerCase().trim().replace(" ", "")) {
					case "0":
					case "":
						driver.switchTo().window(dicOutput.get("ParentWinID"));
						driver.manage().window().maximize();
						Implicitwait(1000);
						return true;
					case "1":
						String parentId = driver.getWindowHandles().iterator().next();
						String ChildId = driver.getWindowHandles().iterator()
								.next();
						driver.switchTo().window(ChildId);
						driver.manage().window().maximize();
						Implicitwait(1000);
						return true;
					case "2":
						String parentId1 = driver.getWindowHandles().iterator().next();
						String ChildId1 = driver.getWindowHandles().iterator().next();
						String ChildId2 = driver.getWindowHandles().iterator().next();
						driver.switchTo().window(ChildId2);
						driver.manage().window().maximize();
						Implicitwait(1000);
						return true;
					}
					return true;
				case "basewindow":
					driver.switchTo().window(dicOutput.get("ParentWinID"));
					return true;
				case "close":
					driver.close();
					return true;
				case "getpagesource":
					dicOutput.put("strOutPut", driver.getPageSource().toString());
					return true;
				case "count":
					dicOutput.put("strOutPut",
							Integer.toString(driver.getWindowHandles().size()));
					return true;

				}

			} catch (Exception ee) {
				ErrDescription = "Unbale to Perform Action : " + strBrowserAction
						+ " On Browser";
			}
			return Flag;
		}


		// #######################################################################################################
		// Description: Explicit Wait Function. Waits for the specific amount of time, until it finds the specified webelement on the DOM
		// #######################################################################################################
		public void ExplicitWait(WebElement element, int time) {
			WebDriverWait wait = new WebDriverWait(driver, time);
			element = wait.until(ExpectedConditions.elementToBeClickable(element));
		}


		// #######################################################################################################
		// Description: End of the test case
		// #######################################################################################################
		public void EndTestCase(String testCaseName) {

			Log.info("--- ENDE DES TESTES: " + testCaseName);

			DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			Calendar calobj = Calendar.getInstance();
			EndDateExecution = df.format(calobj.getTime()).toString();

			// @ get all Open Browser instance.
			int TotalBrower = 0;
			ExecuteActionOnBrowser("count", "");
			TotalBrower = Integer.parseInt(dicOutput.get("strOutPut"));

			// @ focus on Browser and close the browser
			for (int i = 0; i <= TotalBrower; i++) {
				ExecuteActionOnBrowser("focus", String.valueOf(i));
			}
		}
		
		public void execc(WebElement xpath, String strAction, String strValue) throws Exception
		{
			xpath.click();
			// driver.findElement(By.id(username)).click();
			Thread.sleep(1500);
		}


		// #######################################################################################################
		// Description: Execute actions on the page level
		// #######################################################################################################
		public void ExecuteActionOnPage(WebElement xpath, String strAction, String strValue) throws InterruptedException {

			// @ Perform Action.
//			Actions action = new Actions(driver);
//			String parentHandle = driver.getWindowHandle(); // get the current window handle
//			WebDriverWait wait = new WebDriverWait(driver, 5);
//			xpath = wait.until(ExpectedConditions.elementToBeClickable(xpath));

			switch (strAction) {
			case "click":
				Log.info("--- " + xpath.getText() + " element is clicked");
				xpath.click();
				// driver.findElement(By.id(username)).click();
				Thread.sleep(1500);
				break;

//			case "rightclick":
//				Log.info("--- " + xpath.getText() + " element is right clicked");
//				action.contextClick(xpath).perform();
//				Thread.sleep(1500);
//				break;

			case "sendKeys":
				//xpath.clear();
				Log.info("--- " + strValue + " is entered in the element" + xpath.getText());
				xpath.sendKeys(strValue);
				Thread.sleep(1500);
				break;

			case "defineWH":
				xpath.click(); // click some link that opens a new window
				Log.info("--- " + xpath.getText() + " element is clicked");
				for (String winHandle : driver.getWindowHandles()) {
				    driver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
				    Log.info("--- Windows Handling function is called and is navigated to the Child window");
				}
				break;

				//Actions need to be performed in between these two cases
//			case "closeWH":
//				driver.close(); // close newly opened window when done with it
//				driver.switchTo().window(parentHandle); // switch back to the original window
//				Log.info("--- Child window is closed");
//				break;

			case "uncheck":
				if ((xpath).isSelected()) {
					Log.info("--- " + xpath.getText() + " element is unchecked");
					xpath.click();
					Thread.sleep(1500);
					break;
				}

			case "selectbytext":
				Select sel = new Select(xpath);
				Log.info("--- " + xpath.getText() + " element is selected by visible text" + strValue);
				sel.selectByVisibleText(strValue);
				break;

			case "selectbyvalue":
				Select sel1 = new Select(xpath);
				Log.info("--- " + xpath.getText() + " element is selected by value" + strValue);
				sel1.selectByValue(strValue);
				break;

			case "selectbyindex":
				Select sel2 = new Select(xpath);
				Log.info("--- " + xpath.getText() + "element is selected by index" + strValue);
				sel2.selectByIndex(Integer.parseInt(strValue));
				break;

			case "deselectAll":
				Select sel3 = new Select(xpath);
				Log.info("--- " + xpath.getText() + " element is deselected");
				sel3.deselectAll();
				break;
			}
		}


		// #######################################################################################################
		// Description: To verify if the webelement is displayed or not
		// #######################################################################################################
		public boolean IfElementDisplayed(WebElement element, boolean status) {
			return status = element.isDisplayed();
		}


		// #######################################################################################################
		// Description: To fulfill the Log, Excel and Sceenshot criterias for PASS scenario
		// #######################################################################################################
		public void TestCasePassDisplay(int tcNummer, String projekt, String TC, String methodName, int row, int column) throws Exception {
			System.out.println(methodName + "_" + tcNummer + ": " + "method is PASSED");
			Log.info("--- " + methodName + "_" + tcNummer + ": " + "method is PASSED");
			SetCellDataTRPASS("PASS", row, column);
			getscreenshotPASS(projekt, TC, tcNummer, methodName);
		}


		// #######################################################################################################
		// Description: To fulfill the Log, Excel and Sceenshot criterias for FAIL scenario
		// #######################################################################################################
		public void TestCaseFailDisplay(int tcNummer, String projekt, String TC, String methodName, int row, int column) throws Exception {
			System.out.println(methodName + "_" + tcNummer + ": " + "method is FAILED");
			Log.error("--- " + methodName + "_" + tcNummer + ": " + "method is FAILED");
			SetCellDataTRFAIL("FAIL", row, column);
			getscreenshotPASS(projekt, TC, tcNummer, methodName);
		}


		// #######################################################################################################
		// Description: To match two strings if they are equal (equalsIgnoreCase)
		// #######################################################################################################
		public boolean MatchExactString(String set, String subset) {
			if (set.toLowerCase().equalsIgnoreCase(subset.toLowerCase())) {
				Log.info("Two Strings matched");
				return true;
			} else {
				Log.error("Two strings are NOT matched");
				return false;
			}
		}


		// #######################################################################################################
		// Description: To match two strings if they are contained (contains) with eliminating the case sensitive
		// #######################################################################################################
		public boolean MatchContainsString(String set, String subset) {
			if (set.toLowerCase().trim().contains((subset.toLowerCase().trim()))) {
				Log.info("Two Strings matched");
				return true;
			} else {
				Log.error("Two strings are NOT matched");
				return false;
			}
		}


		// #######################################################################################################
		// Description: To match two strings if they are contained (contains) with eliminating the case sensitive
		// #######################################################################################################
		public boolean ElementExistenceCheckBoolean(String Xpath, WebElement element) {
			try {
				element = driver.findElement(By.xpath(Xpath));

				return true;
			} catch (Exception e) {
				ErrDescription = "element does not exist on page level";
				Log.error("--- " + element.getText() + "is NOT displayed");
			}
			return false;
		}


		// #######################################################################################################
		// Description: To mouse hover and hold on the specified web element
		// #######################################################################################################
		public boolean MouseOverandHold(WebElement element) {
			try {
				Mouse mouse = ((HasInputDevices) driver).getMouse();
				Locatable hoverItem = (Locatable) element;
				mouse.mouseMove(hoverItem.getCoordinates());
				Log.info("--- MouseOver for " + element.getText()
						+ " element is successfully displayed");
				return true;
			} catch (Exception e) {
				Log.error("--- MouseOver for " + element.getText()
						+ " element is NOT displayed");
			}
			return false;
		}


		// #######################################################################################################
		// Description: To highlight on the specified web element
		// #######################################################################################################
		public boolean elementHighlight(WebElement element) {
			try {
				for (int i = 0; i < 5; i++) {
					JavascriptExecutor js = (JavascriptExecutor) driver;
					js.executeScript(
							"arguments[0].setAttribute('style', arguments[1]);",
							element, "color: yellow; border: 5px solid yellow;");
					js.executeScript(
							"arguments[0].setAttribute('style', arguments[1]);",
							element, "");
					Log.info("--- Element " + element.getText() + " is highlighted");
					Thread.sleep(300);
				}
				return true;
			} catch (Exception e) {
				Log.error("--- Element " + element.getText()
						+ " is NOT highlighted");
			}
			return false;
		}


		// #######################################################################################################
		// Description: Wait implicit wait for the specified seconds
		// #######################################################################################################
		public void Implicitwait(int intTimeOut) {
			driver.manage().timeouts().implicitlyWait(intTimeOut, TimeUnit.SECONDS);
		}


		// #######################################################################################################
		// Description: Function to take the screenshot at a particular point for the passed Testcase
		// #######################################################################################################
		public void getscreenshotPASS(String projekt, String TC, int TCnumber, String className) throws Exception {
			try {
				SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");// dd/MM/yyyy
				Date now = new Date();
				String strDate = sdfDate.format(now);

				File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
				String fName = "Screenshots\\" + projekt + "\\" + TC + "\\" + TCnumber + "_" + className + "\\" + "PASSED Screenshots" + "\\" + strDate + ".png";
				FileUtils.copyFile(scrFile, new File(fName));
				Log.info("Screenshot is successfully captured for the PASSED testcase:" + TCnumber + ": " +TC);
			}
			catch (IOException e) {
				e.getMessage();
				System.out.println("Failed to capture screenshot: " + e.getMessage());
				Log.error("Screenshot is NOT captured for the PASSED testcase:" + TCnumber + ": " +TC);
			}
		}

		// #######################################################################################################
	        // Description: Function to take the screenshot at a particular point for the failed Testcase
	        // #######################################################################################################
	        public void getscreenshotFAIL(String projekt, String TC, int TCnumber, String className) throws Exception {
	                try {
	                        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");// dd/MM/yyyy
	                        Date now = new Date();
	                        String strDate = sdfDate.format(now);

	                        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	                        String fName = "Screenshots\\" + projekt + "\\" + TC + "\\" + TCnumber + "_" + className + "\\" + "FAILED Screenshots" + "\\" + strDate + ".png";
	                        FileUtils.copyFile(scrFile, new File(fName));
	                        Log.info("Screenshot is successfully captured for the FAILED testcase:" + TCnumber + ": " +TC);
	                }
	                catch (IOException e) {
	                        e.getMessage();
	                        System.out.println("Failed to capture screenshot: " + e.getMessage());
	                        Log.error("Screenshot is NOT captured for the FAILED testcase:" + TCnumber + ": " +TC);
	                }
	        }


		// #######################################################################################################
		// Description: Execute action on the popup
		// #######################################################################################################
		public boolean ExecuteActionOnPopup(String strAction) {
			// @ verify Pop up is present or not.
			try {
				switch (strAction.toLowerCase().trim()) {
				case "accept":
				case "ok":
				case "yes":
					driver.switchTo().alert().accept();
					break;
				case "dismiss":
				case "no":
				case "cancel":
					driver.switchTo().alert().dismiss();
					break;
				case "gettext":
					dicOutput.put("strOutPut", driver.switchTo().alert().getText());
					break;
				}
			} catch (Exception e) {
				Log.error("Exception message: " + e);
				return false;
			}

			return true;
		}


		// #######################################################################################################
		// Description: To get the temp path and return using String
		// #######################################################################################################
		public String GetTempPath() {
			return System.getProperty("java.io.tmpdir");
		}


		// #######################################################################################################
		// Description: To save the HTML reports path
		// #######################################################################################################
		public void SaveHTMLReportsPath() {
			boolean blnFlag = false;
			String HTMLReportsLink = GetTempPath() + "AUT_Results\\Reports\\";
			blnFlag = CreateDirectory(HTMLReportsLink);
			if (blnFlag) {
				try {
					Writer output;
					output = new BufferedWriter(new FileWriter(HTMLReportsLink
							+ "HTMLRepotsLink.txt", true));
					String newLine = System.getProperty("line.separator");
					output.append(newLine + sReportFileName);
					output.close();
				} catch (Exception e) {
				}
			}
		}


		// #######################################################################################################
		// Description: To create a directory on the specified path
		// #######################################################################################################
		public boolean CreateDirectory(String DirectoryName) {
			File file = new File(DirectoryName);
			if (!file.exists()) {
				if (file.mkdirs()) {
					return true;
				} else {
					ErrDescription = "Failed to create directory!";
					return false;
				}
			}
			return true;
		}


		// #######################################################################################################
		// Description: To delete the directory on the specified path
		// #######################################################################################################
		public void DeleteDirectory(String DirectoryName) {
			File directory = new File(DirectoryName);
			if (!directory.exists()) {
				return;
			} else {
				try {
					DeleteFolderContent(directory);
				} catch (Exception e) {
					System.out.println("Exception");
				}
			}

		}


		// #######################################################################################################
		// Description: To delete the folder content
		// #######################################################################################################
		public void DeleteFolderContent(File file) {
			if (file.isDirectory()) {

				// directory is empty, then delete it
				if (file.list().length == 0) {
					file.delete();

				} else {
					// list all the directory contents
					String files[] = file.list();

					for (String temp : files) {
						// construct the file structure
						File fileDelete = new File(file, temp);

						// recursive delete
						DeleteFolderContent(fileDelete);
					}

					// check the directory again, if empty then delete it
					if (file.list().length == 0) {
						file.delete();
					}
				}

			} else {
				// if file, then delete it
				file.delete();
			}
		}


		// #######################################################################################################
		// Description: To get the time difference
		// #######################################################################################################
		public String GetTimeDiffernce(String dateStart, String dateStop) {
			String Difference = "";
			SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			try {
				java.util.Date dt1 = format.parse(dateStart);
				java.util.Date dt2 = format.parse(dateStop);
				long diff = dt2.getTime() - dt1.getTime();
				long diffSeconds = TimeUnit.MILLISECONDS.toSeconds(diff) % 60;
				long diffMinutes = TimeUnit.MILLISECONDS.toMinutes(diff) % 60;
				long diffHours = TimeUnit.MILLISECONDS.toHours(diff) % 24;
				String Hour = "";
				String Minutes = "";
				String Second = "";
				if (diffHours < 10) {
					Hour = "0" + diffHours;
				} else {
					Hour = String.valueOf(diffHours);
				}
				if (diffMinutes < 10) {
					Minutes = "0" + diffMinutes;
				} else {
					Minutes = String.valueOf(diffMinutes);
				}
				if (diffSeconds < 10) {
					Second = "0" + diffSeconds;
				} else {
					Second = String.valueOf(diffSeconds);
				}
				Difference = Hour + ":" + Minutes + ":" + Second;
			} catch (Exception e) {
			}
			return Difference;
		}


		// #######################################################################################################
		// Description: To read contents from a text file and return the content using String
		// #######################################################################################################
		public String ReadAllTextFromFile(String FilePath) {
			String Text = "";
			try {
				Text = new String(Files.readAllBytes(Paths.get(FilePath)));
			} catch (Exception e) {
			}
			return Text;
		}

		// #######################################################################################################
		// Description: To send an email on the specified credentials using PORT and HOST
		// #######################################################################################################
		public void SendMail() {
			final String username = "arun.deepak@gmx.de";
			final String password = "12345678";

			Properties props = new Properties();
			props.put("mail.smtp.auth", true);
			props.put("mail.smtp.starttls.enable", true);
			props.put("mail.smtp.host", "mail.gmx.net");
			props.put("mail.smtp.port", "995");

			Session session = Session.getInstance(props,
					new javax.mail.Authenticator() {
						protected PasswordAuthentication getPasswordAuthentication() {
							return new PasswordAuthentication(username, password);
						}
					});

			try {

				Message message = new MimeMessage(session);
				message.setFrom(new InternetAddress("from.arun.deepak@gmx.de"));
				message.setRecipients(Message.RecipientType.TO,
						InternetAddress.parse("to.arundeepak_02@ymail.com"));
				message.setSubject("Testing Subject");
				message.setText("PFA");

				MimeBodyPart messageBodyPart = new MimeBodyPart();

				Multipart multipart = new MimeMultipart();

				messageBodyPart = new MimeBodyPart();
				String file = "test-output/testng-reports.js";
				String fileName = "testng reports";
				DataSource source = new FileDataSource(file);
				messageBodyPart.setDataHandler(new DataHandler(source));
				messageBodyPart.setFileName(fileName);
				multipart.addBodyPart(messageBodyPart);

				message.setContent(multipart);

				System.out.println("Sending");

				Transport.send(message);

				System.out.println("Done");

			} catch (MessagingException e) {
				e.printStackTrace();
			}
		}

		// #######################################################################################################
		// Description: TEST RESULTS# To configure and enter the test results in Excel using POI
		// #######################################################################################################
		// Set the File path and Sheetname as Arguments to set the excel file
		public void SetExcelFileTR(String Path, String SheetName) throws Exception {


			try {
				Path_TestDataTR = Path;

				// Open the Excel file
				FileInputStream ExcelFile = new FileInputStream(Path);

				// Access the required test data sheet
				ExcelWBookTR = new XSSFWorkbook(ExcelFile);
				ExcelWSheetTR = ExcelWBookTR.getSheet(SheetName);
			} catch (Exception e) {
				throw (e);
			}
		}

		// oiriginal To write in the Excel cell, Row num and Col num are the parameters
		public void SetCellDataTRFAIL(String Result, int RowNum, int ColNum) throws Exception
		{
			try {
				if (ExcelWSheetTR.getRow(RowNum) == null) {
					RowTR = ExcelWSheetTR.createRow(RowNum);
				}
				else
				{
				RowTR = ExcelWSheetTR.getRow(RowNum);
				CellTR = RowTR.getCell(ColNum, xRow.RETURN_BLANK_AS_NULL);
				}

				if (CellTR == null)
				{
					CellTR = RowTR.createCell(ColNum);
					CellTR.setCellValue("");
					CellTR.setCellValue(Result);
				}
				else
				{
					CellTR.setCellValue(Result);
				}

				// Constant variables Test Data path and Test Data file name
				FileOutputStream fileOut = new FileOutputStream(Path_TestDataTR);
				ExcelWBookTR.write(fileOut);
				fileOut.flush();
				fileOut.close();
			}
			catch (Exception e)
			{
				e.printStackTrace();
				throw (e);
			}
		}

		// duplicate To write in the Excel cell, Row num and Col num are the parameters
	        public void SetCellDataTRPASS(String Result, int RowNum, int ColNum) throws Exception
	        {
	            try {
	                if (ExcelWSheetTR.getRow(RowNum) == null) {
	                        RowTR = ExcelWSheetTR.createRow(RowNum);
	                }
	                else
	                {
	                RowTR = ExcelWSheetTR.getRow(RowNum);
	                CellTR = RowTR.getCell(ColNum, xRow.RETURN_BLANK_AS_NULL);
	                }

	                if (CellTR == null)
	                {
	                        CellTR = RowTR.createCell(ColNum);
	                        CellTR.setCellValue("");
	                        CellTR.setCellValue(Result);
	                }
	                else
	                {
	                        CellTR.setCellValue(Result);
	                }

	                // Constant variables Test Data path and Test Data file name
	                FileOutputStream fileOut = new FileOutputStream(Path_TestDataTR);
	                ExcelWBookTR.write(fileOut);
	                fileOut.flush();
	                fileOut.close();
	        }
	        catch (Exception e)
	        {
	                e.printStackTrace();
	                throw (e);
	        }
	        }

		// This method is to read the test data from the Excel cell, in this we are passing parameters as Row num and Col num
		public String GetCellData(int RowNum, int ColNum) throws Exception {

			try {

				CellTR = ExcelWSheetTR.getRow(RowNum).getCell(ColNum);
				String CellData;
				switch (CellTR.getCellType()) {
				case NUMERIC:
					System.out.println("its an numeric value");
					CellData = "" + (int) CellTR.getNumericCellValue();
					break;
				case STRING:
					CellData = CellTR.getStringCellValue();
					break;
				default:
					CellData = "";
				}
				return CellData.trim();
			}
			catch (Exception e)
			{
				e.printStackTrace();
				return "";
			}
		}

		// To get the last row number
		public int GetLastRowNumber() {
			return ExcelWSheetTR.getLastRowNum();
		}

		// To get the row number in String
		public String GetRow(int rowNum) {
			return ExcelWSheetTR.getRow(rowNum).toString();
		}

		// To check of the specific row is empty
		public boolean IsRowEmpty(int row, int exceed) {

			RowTR = ExcelWSheetTR.getRow(row);
			if (RowTR == null)
				return (true);

			for (int c = RowTR.getFirstCellNum(); c < exceed; c++) {
				if (RowTR.getCell(c) == null
						|| RowTR.getCell(c).toString().trim().equals(""))
					return true;
			}
			return false;
		}

		// #######################################################################################################
		// Description: TEST DATA# To configure and get the test data in Excel using POI
		// #######################################################################################################
		// Set the File path and Sheetname as Arguments to set the excel file
			public void SetExcelFileTD(String Path, String SheetName) throws Exception {

				try {
					Path_TestDataTD = Path;

					// Open the Excel file
					FileInputStream ExcelFile = new FileInputStream(Path);

					// Access the required test data sheet
					ExcelWBookTD = new XSSFWorkbook(ExcelFile);
					ExcelWSheetTD = ExcelWBookTD.getSheet(SheetName);
				} catch (Exception e) {
					throw (e);
				}
			}

			// This method is to read the test data from the Excel cell, in this we are passing parameters as Row num and Col num
			public String GetCellDataTD(int RowNum, int ColNum) throws Exception {

				try {

					CellTD = ExcelWSheetTD.getRow(RowNum).getCell(ColNum);
					String CellData;
					switch (CellTD.getCellType()) {
					case NUMERIC:
						System.out.println("its an numeric value");
						CellData = "" + (int) CellTD.getNumericCellValue();
						break;
					case STRING:
						CellData = CellTD.getStringCellValue();
						break;
					default:
						CellData = "";
					}
					return CellData.trim();
				}
				catch (Exception e)
				{
					e.printStackTrace();
					return "";
				}
			}

}
