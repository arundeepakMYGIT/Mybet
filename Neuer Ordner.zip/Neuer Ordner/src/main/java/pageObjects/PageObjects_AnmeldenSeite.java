package pageObjects;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import genericClass.GenericClass;

public class PageObjects_AnmeldenSeite extends GenericClass {
	
	@FindBy(id = "nav-logo-sprites")
	public WebElement amazonLogo;
	
	@FindBy(id = "nav-link-accountList")
	public WebElement anmeldenButton;
	
	@FindBy(id = "auth-create-account-link")
	public WebElement kontoErstellenButton;
	
	@FindBy(id = "ap_customer_name")
	public WebElement nameTextfeld;

	@FindBy(id = "ap_email")
	public WebElement mobiltelefonnummerEmailTextfeld;
	
	@FindBy(id = "ap_password")
	public WebElement passwortTextfeld;
	
	@FindBy(id = "ap_password_check")
	public WebElement passwortWiederholenTextfeld;
	
	@FindBy(id = "continue")
	public WebElement weiterButton;
	
	@FindBy(xpath = "//*[contains(text(), 'Geben Sie Ihre E-Mail-Adresse oder Mobiltelefonnummer ein')]")
	public WebElement telefonnummerEmailFehlermeldung;

	//------------------------------------------------------------------------------------------------
	
	public void amazonLogoKlicken() throws InterruptedException, IOException {
		click(amazonLogo, "Amazon Logo");
	}
	
	public void anmeldenButtonKlicken() throws InterruptedException, IOException {
		click(anmeldenButton, "Anmelden Button");
	}
	
	public void kontoErstellenButtonKlicken() throws InterruptedException, IOException {
		click(kontoErstellenButton, "Konto Erstellen Button");
	}
	
	public void kontoErstellenTextfelder(String name, String telefonnummerEmail, String passwort, String passwortWiederholen) throws InterruptedException, IOException {
		sendKeys(nameTextfeld, name, "Name Textfeld");
		sendKeys(mobiltelefonnummerEmailTextfeld, telefonnummerEmail, "Telefonnummer/Email");
		sendKeys(passwortTextfeld, passwort, "Passwort Textfeld");
		sendKeys(passwortWiederholenTextfeld, passwortWiederholen, "Passwort Wiederholen Textfeld");
		
		click(weiterButton, "Weiter Button");
	}
	
}
