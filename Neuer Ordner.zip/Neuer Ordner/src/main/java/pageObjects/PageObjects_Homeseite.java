package pageObjects;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import genericClass.GenericClass;

public class PageObjects_Homeseite extends GenericClass{
	
	@FindBy(id = "twotabsearchtextbox")
	public WebElement sucheTextfeld;
	
	@FindBy(id = "nav-search-submit-button")
	public WebElement sucheButton;
	
	@FindBy(className  = "nav-search-submit-button")
	public List<WebElement> sucheErgebnisse;
	
	//------------------------------------------------------------------------------------------------
	
	public void searchTextfeldSendkeys(String wert) throws InterruptedException, IOException {
		sendKeys(sucheTextfeld, wert, "Homeseite Suche");
	}
	
	public void sucheButtonKlicken() throws InterruptedException, IOException {
		click(sucheButton, "Suche Button");
	}
	
	public boolean vergleichErgebnisse(String wert) {
		boolean flag = false;
		for(WebElement e :sucheErgebnisse) {
		    System.out.println("Suche Ergebnisse: "+e.getText());
		    hardAssert.assertEquals(e.getText(), wert);
		    flag = true;
		}
		return flag;
	}
}
