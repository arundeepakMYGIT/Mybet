package pageObjects;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import genericClass.GenericClass;

public class PageObjects_Wordpad extends GenericClass{
	
	@FindBy(name = "RTF-Fenster")
	public WebElement wordpadTextfeld;
	
	@FindBy(name = "Schließen")
	public WebElement wordpadSchliessen;
	
	//@FindBy(name  = "Möchten Sie die Änderungen an Unbenannt speichern?")
	@FindBy(id = "MainInstruction")
	public WebElement hinweisPopup;
	
	//------------------------------------------------------------------------------------------------
	
	public void wordpadTextfeldSendkeys(String wert) throws InterruptedException, IOException {
		sendKeysWin(wordpadTextfeld, wert, "Textfeld in Wordpad");
	}
	
	public void wordpadSchliessenKlicken() throws InterruptedException, IOException {
		clickWin(wordpadSchliessen, "Schliessen Button");
	}

}
