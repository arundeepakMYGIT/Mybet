package stepDefinitions;

import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import genericClass.GenericClass;
import pageObjects.PageObjects_Homeseite;

public class AmazonSuche extends GenericClass{
	
	public PageObjects_Homeseite HS;
	
	public static boolean istDurch = true;
	
	@Given("^Amazon Seite aufrufen$")
	public void amazon_Seite_aufrufen() throws Throwable {
		
		try {
			if(istDurch) {
				extentReport("", "Report", "", throwable);
				
				extentReport("Testfall 1 Ueberpruefen von Suche Funktion", "Testfall", "", throwable);
				
				browserPropertyUndLog();
				HS = PageFactory.initElements(driverBrowser, PageObjects_Homeseite.class);
				istDurch = false;
			}
		}
		catch (Exception e) {
			e.getMessage();
			extentReport("", "fail", "Testfallergebnis: Fehler aufgetreten beim Aufruf der Amazonseite", e);
		}
	}

	@When("^im Suchetextfeld iphone eingeben und Suche anklicken$")
	public void im_Suchetextfeld_eingeben_und_Suche_anklicken() throws Throwable {
		try {
			HS.searchTextfeldSendkeys(properties.getProperty("sucheText"));
			HS.sucheButtonKlicken();
		}
		catch (Exception e) {
			e.getMessage();
			extentReport("", "fail", "Testfallergebnis: Fehler aufgetreten waehrend der Eingabe im Suche Textfeld", e);
		}
	}

	@Then("^Sucheergebnisse entsprechen dem eingegebenen Text$")
	public void sucheergebnisse_entsprechen_dem_eingegebenen_Text() throws Throwable {
		try {
			HS.vergleichErgebnisse(properties.getProperty("sucheText"));
			TestCasePassDisplay("Sucheergebnisse entsprechen dem eingegebenen Wert in Suchetextfeld ("+properties.getProperty("sucheText")+")", "");
		}
		catch(Exception e) {
			e.getMessage();
			TestCaseFailDisplay("Sucheergebnisse entsprechen dem eingegebenen Wert NICHT in Suchetextfeld ("+properties.getProperty("sucheText")+")", "", e);
		}
	}
}
