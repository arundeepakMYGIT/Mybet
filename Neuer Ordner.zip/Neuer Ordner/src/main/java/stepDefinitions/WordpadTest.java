package stepDefinitions;

import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import genericClass.GenericClass;
import pageObjects.PageObjects_Homeseite;
import pageObjects.PageObjects_Wordpad;

public class WordpadTest extends GenericClass{
	
public PageObjects_Homeseite HS;

	public PageObjects_Wordpad NT;
	
	public static boolean istDurch = true;
	
	@Given("^Wordpad oeffnen$")
	public void Wordpad_oeffnen() throws Throwable {
		try {
			if(istDurch) {
				extentReport("Testfall 3 Ueberpruefen der Fehlermeldung in Wordpad", "Testfall", "", throwable);
				winiumDriverSetupUndAufrufWindowsapp("C:\\Program Files\\Windows NT\\Accessories\\wordpad.exe", "Wordpad");
				NT = PageFactory.initElements(driverWinium, PageObjects_Wordpad.class);
				istDurch = false;
			}
		} 
		catch (Exception e) {
			e.getMessage();
			extentReport("", "fail", "Testfallergebnis: Fehler aufgetreten beim Aufruf des Wordpads", e);
		}
	}

	@When("^beliebiges Text eingeben$")
	public void beliebiges_Text_eingeben() throws Throwable {
		try {
			NT = PageFactory.initElements(driverWinium, PageObjects_Wordpad.class);
			String text = properties.getProperty("Wordpadtext");
			NT.wordpadTextfeldSendkeys(text);
		}
		catch (Exception e) {
			e.getMessage();
			extentReport("", "fail", "Testfallergebnis: Fehler aufgetreten bei der Eingabe in Wordpad", e);
		}
	}

	@And("^Fenster schliessen$")
	public void fenster_schliessen() throws Throwable {
		try {
			NT.wordpadSchliessenKlicken();
		}
		catch (Exception e) {
			e.getMessage();
			extentReport("", "fail", "Testfallergebnis: Fehler aufgetreten beim Schliessen des Wordpads", e);
		}
	}

	@Then("^Popup taucht auf, ob man die Aenderungen speichern will$")
	public void popup_taucht_auf_ob_man_die_Aenderungen_speichern_will() throws Throwable {
		try {
			NT = PageFactory.initElements(driverWinium, PageObjects_Wordpad.class);
			hardAssert.assertEquals(true, NT.hinweisPopup.isDisplayed());
			TestCasePassDisplay("Popup ist aufgetaucht und gefragt, ob die Aenderungen gespeichert werden muessen", "");
		}
		catch (Exception e) {
			e.getMessage();
			TestCaseFailDisplay("Popup ist NICHT aufgetaucht und gefragt, ob die Aenderungen gespeichert werden muessen", "", e);
		}
		driverWinium.close();
	}
}