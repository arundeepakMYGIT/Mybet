package stepDefinitions;

import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import genericClass.GenericClass;
import pageObjects.PageObjects_AnmeldenSeite;

public class AmazonRegistration extends GenericClass{
	
	public PageObjects_AnmeldenSeite AS;
	
	public static boolean istDurch = true;
	
	@Given("^Amazon Logo anklicken$")
	public void amazon_Webseite_aufrufen() throws Throwable {
		try {
			if(istDurch) {
				extentReport("Testfall 2 Fehler Ueberpruefung bei dem Erstellen des Kontos", "Testfall", "", throwable);
				
				AS = PageFactory.initElements(driverBrowser, PageObjects_AnmeldenSeite.class);
				AS.amazonLogoKlicken();
				
				istDurch = false;
			}
		}
		catch (Exception e) {
			e.getMessage();
			extentReport("", "fail", "Testfallergebnis: Fehler aufgetreten beim Klicken des Amazon Logos", e);
		}
	}
	

	@When("^Konto erstellen Button anklicken$")
	public void konto_erstellen_Button_anklicken() throws Throwable {
		try {
			AS.anmeldenButtonKlicken();
			AS.kontoErstellenButtonKlicken();
		}
		catch (Exception e) {
			e.getMessage();
			extentReport("", "fail", "Testfallergebnis: Fehler aufgetreten beim Klicken des Konto Erstellen", e);
		}
	}

	@And("^Eingaben in folgenden Feldern vornehmen Name, Passwort, Passwort wiederholen und Weiter anklicken$")
	public void eingaben_in_folgenden_Feldern_vornehmen_Name_Passwort_Passwort_wiederholen_und_Weiter_anklicken() throws Throwable {
		try {
			String name = properties.getProperty("name");
			String telefonnummerEmail = properties.getProperty("telefonnummerEmail");
			String passwort = properties.getProperty("passwort");
			String passwortWiederholen = properties.getProperty("passwortWiederholen");
			AS.kontoErstellenTextfelder(name, telefonnummerEmail, passwort, passwortWiederholen);
		}
		catch (Exception e) {
			e.getMessage();
			extentReport("", "fail", "Testfallergebnis: Fehler aufgetreten beim Klicken des Konto Erstellen", e);
		}
	}

	@Then("^Fehlermeldung wird angezeigt, dass man Telefonnummer oder E-Mail eingeben muss$")
	public void fehlermeldung_wird_angezeigt_dass_man_Telefonnummer_eingeben_muss() throws Throwable {
		try {
			hardAssert.assertEquals(true, AS.telefonnummerEmailFehlermeldung.isDisplayed());
			TestCasePassDisplay("Fehlermeldung ist angezeigt, dass eine Telefonnummer oder Email eingegeben werden muss", "");
		}
		catch (Exception e) {
			
			e.getMessage();
			TestCaseFailDisplay("Fehlermeldung ist NICHT angezeigt, dass eine Telefonnummer oder Email eingegeben werden muss", "", e);
		}
		driverBrowser.close();
	}
}
