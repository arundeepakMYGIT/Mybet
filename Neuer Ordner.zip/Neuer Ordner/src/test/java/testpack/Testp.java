package testpack;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Testp {
	
	//public WebDriver driverBrowser;
	
	@Test
	public void tttt() {
		System.setProperty("webdriver.chrome.driver", "Resources/chromedriver106.exe");
//		ChromeOptions options = new ChromeOptions();
		//WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://demo.guru99.com/test/newtours/");
		driver.manage().window().maximize();
		
		
//		System.setProperty("webdriver.chrome.driver", "Resources/chromedriver.exe");
//		driverBrowser = new ChromeDriver();
//		driverBrowser.manage().window().maximize();
//		System.out.println("URL is");
//		driverBrowser.get("https://www.amazon.de/");
	}

}
