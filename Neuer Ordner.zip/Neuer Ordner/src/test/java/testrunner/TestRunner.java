package testrunner;

import org.testng.annotations.Test;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
		plugin= {"pretty",
				"html:target/cucumber-reports/cucumber.html",
				"json:target/cucumber-reports/cucumber.json"
		},
		features= {"Features/1Suche.feature", "Features/2Registration.feature", "Features/3WindowsTest.feature"},
		glue= {"stepDefinitions"},
//		tags = {"@Suche"},
		monochrome= true
		)

@Test
public class TestRunner extends AbstractTestNGCucumberTests{

}